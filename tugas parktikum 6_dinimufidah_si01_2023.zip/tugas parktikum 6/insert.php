<?php

include 'koneksi.php';    

$nama_anggota = $_POST['nama_anggota'];
$jekel = $_POST['jekel'];
$tanggal_daftar = $_POST['tanggal_daftar'];
$alamat = $_POST['alamat'];

$query = "INSERT INTO anggota (nama_anggota, jekel, tanggal_daftar, alamat)
            VALUES ('$nama_anggota', '$jekel', '$tanggal_daftar', '$alamat')";

if( $conn->query($query) === TRUE ) {
    header("Location: index.php");
}


$conn->close();