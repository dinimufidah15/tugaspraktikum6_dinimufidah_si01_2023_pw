<?php

    include 'koneksi.php';

    $qry = "SELECT * FROM anggota";
    $result = $conn->query($qry);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD anggota koperasi</title>
</head>
<body>
    <h2>Data anggota</h2>
    <table border="1" style="width:100%">
        <tr>
            <th>id_anggota</th>
            <th>Nama_anggota</th>
            <th>jekel</th>
            <th>tanggal_daftar</th>
            <th>alamat</th>
        </tr>
     

        <?php while( $row = $result->fetch_assoc() ) :  ?>
        <tr>
            <td> <?= $row['id_anggota'] ?>  </td>
            <td><?= $row['nama_anggota'] ?></td>
            <td><?= $row['jekel'] ?></td>
            <td><?= $row['tanggal_daftar'] ?></td>
            <td><?= $row['alamat'] ?></td>
        </tr>
        <?php  endwhile  ?>

    </table>
    <br>
    <h2>Tambah anggota</h2>
    <form action="insert.php" method="POST">
        nama_anggota: <input type="text" name="nama_anggota" required><br>
        jekel: <input type="text" name="jekel" required><br>
        tanggal_daftar: <label for="tanggal_daftar">Tanggal:</label>
    <input type="date" id="tanggal_daftar" name="tanggal_daftar"><br>
        alamat: <input type="text" name="alamat" required><br>
        <input type="submit" value="Tambah">
    </form>
</body>
</html>