<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'koperasi';

$conn = new mysqli($host, $username, $password, $database);